from scipy import io

import numpy as np

import matplotlib.pyplot as plt

import matplotlib

matplotlib.use('TkAgg')

from numpy.fft import fft, fftfreq, irfft, rfft2, rfft, rfftfreq

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

from matplotlib.figure import Figure

import tkinter as tk

from tkinter import filedialog

from tkinter import ttk

from tkinter import *

import os

import math

import time

from fractions import Fraction

#Import analysis functions
from Analysis_v12 import pressureAnalysis 

#Change from v1 - Reworked so that rescaling occurs in GUI file
#Change from v2 - Returned to former approach of scaling occuring in Analysis

#Define global variables 
u = [[[]]]
v = [[[]]]
x = [[[]]]
y = [[[]]]

x_cut = [[[]]]
y_cut = [[[]]]
p = [[[]]]

#Get cmap
#Purple / Orange
#mycmap = plt.get_cmap('gnuplot2')
#Plasma
#mycmap = plt.get_cmap('plasma')
#Viridis
mycmap = plt.get_cmap('viridis')




fileName = "PressureData.mat"
pagenum = 0

#Create main GIU window

root = Tk()

root.title('PIV Analysis ')

root.geometry('1500x850')

 

 

####################################################### Define variables to change using options tabs ################################################

 

 

n = IntVar(0,8)

Ff = IntVar(0,45)

frame = IntVar(0,0)

Table_Rpm = IntVar(0,10)

Camera_Fps = IntVar(0,120)

 
def _quit():
    root.quit()     # stops mainloop
    root.destroy()  # this is necessary on Windows to prevent
                    # Fatal Python Error: PyEval_RestoreThread: NULL tstate

 

######################################################### Plot canvas for graph #########################################################

 

 

f = Figure(figsize=(8.2,6.4), dpi=120)

plot_frame = Frame(root)

plot_frame.grid(row=1, column=4, rowspan=50)

 

canvas = FigureCanvasTkAgg(f, plot_frame)

canvas.draw()

canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

 

toolbar = NavigationToolbar2Tk(canvas,plot_frame)

toolbar.update()

canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

 

 

######################################################### Find Directory and load values into app #########################################################

 

 

directoryLabel= Label(root, text='C:/Users/Admin/Desktop/Experiments')

directoryLabel.grid(row=1,column=1 )



def directoryClick():

    root.directory = filedialog.askdirectory()

    directoryLabel= Label(root, text=root.directory)

    directoryLabel.grid(row=1,column=1 )

 

directoryButton = Button(root, text='Set directory', command=directoryClick)

directoryButton.grid(row=1,column=0 )

 

def Import():

    global u, v

    u_filtered = io.loadmat(os.path.join(root.directory, 'u_filtered.mat'))

    u_filtered = u_filtered['u_filtered']

    u_filtered = np.squeeze(u_filtered)

    u = np.empty((u_filtered.shape[0], u_filtered[0].shape[0], u_filtered[0].shape[1]))

    for i in range(u.shape[0]):

        u[i] = u_filtered[i]

    v_filtered = io.loadmat(os.path.join(root.directory, 'V_filtered.mat'))

    v_filtered = v_filtered['v_filtered']

    v_filtered = np.squeeze(v_filtered)

    v = np.empty((v_filtered.shape[0], v_filtered[0].shape[0], v_filtered[0].shape[1]))

    for i in range(v.shape[0]):

        v[i] = v_filtered[i]

    if u.shape == v.shape:

        sizeLabelx = Label(root, text=v.shape)

        sizeLabelx.grid(row=1,column=4)

 

 

directoryButton = Button(root, text='Import', command=Import, padx=15)

directoryButton.grid(row=1,column=2 )

 

 

######################################################### Create interface for graphical manipulation #########################################################

 

tabControl = ttk.Notebook(root)

 

tab1 = ttk.Frame(tabControl)

tabControl.add(tab1, text='Line Plot')

tabControl.grid(row=5, column=0, columnspan = 3)

blankt1 = Label(tab1, text=" ")

blankt1.grid(row=0, column=0)

 

tab2 = ttk.Frame(tabControl)

tabControl.add(tab2, text='Animation')

tabControl.grid(row=5, column=0, columnspan = 3)

blankt2 = Label(tab2, text=" ")

blankt2.grid(row=0, column=0)

 

tab3 = ttk.Frame(tabControl)

tabControl.add(tab3, text='Average')

tabControl.grid(row=5, column=0, columnspan = 3)

blankt3 = Label(tab3, text=" ")

blankt3.grid(row=0, column=0)

 

tab4 = ttk.Frame(tabControl)

tabControl.add(tab4, text='Wave Visualisation')

tabControl.grid(row=6, column=0, columnspan = 3)

blankt4 = Label(tab4, text=" ")

blankt4.grid(row=0, column=0)

 

tab5 = ttk.Frame(tabControl)

tabControl.add(tab5, text='Frequency')

tabControl.grid(row=6, column=0, columnspan = 3)

blankt5 = Label(tab5, text=" ")

blankt5.grid(row=0, column=0)

 
tab6 = ttk.Frame(tabControl)
tabControl.add(tab6, text = 'Pressure from raw')
blankt6 = Label(tab6, text=" ")
blankt6.grid(row=0, column=0)

tab7 = ttk.Frame(tabControl)
tabControl.add(tab7, text = 'Pressure from processed')
blankt7 = Label(tab7, text=" ")
blankt7.grid(row=0, column=0)



 

######################################################### Dropdown selection of graph output #########################################################

 

 

choice = StringVar()

choice.set('Average Velocity Plot')

 

drop = OptionMenu(root, choice, 'Validation Line Plot','Velocity Animation', 'Average Velocity Plot', 'Inertial Wave Visualisation', 'Frequency Analysis', 'Horizontal IW')

drop.grid(row=3, column=1, columnspan = 1)

 

def callback(*args):

    if choice.get() == 'Average Velocity Plot':

        global u, v

        u1 = np.mean(u, axis=0)

        v1 = np.mean(v, axis=0)

        a = np.arange(0,u.shape[2],1)

        b = np.arange(0,u.shape[1],1)

        mag = np.sqrt(u1**2 + v1**2)

        A , B = np.meshgrid(a,b)

        f.clear()

        quiv = f.add_subplot(111)

        quiv.quiver(A,B,u1,v1,mag)

        quiv.xaxis.set_ticks([])

        quiv.yaxis.set_ticks([])

        quiv.plot()

        canvas.draw()

        canvas.get_tk_widget().pack()

    if choice.get() == 'Validation Line Plot':

        n.set(ent1t1.get())

        u1 = np.mean(u, axis=0)

        v1 = np.mean(v, axis=0)

        rot = -1*np.rot90(u1)

        zeros = np.full_like(rot,0)

        for i in range(rot.shape[0]):

            if((i % n.get()) != 0):

                rot[i,:] = 0

        f.clear()

        val = f.add_subplot(111)

        c = np.arange(0,rot.shape[1],1)

        d = np.arange(0,rot.shape[0],1)

        C , D = np.meshgrid(c,d)

        val.quiver(C,D,zeros,rot,angles='xy', scale_units='xy', scale=(1/(n.get()*0.7)))

        val.xaxis.set_ticks([])

        val.yaxis.set_ticks([])

        val.plot()

        canvas.draw()

        canvas.get_tk_widget().pack()

    if choice.get() == 'Inertial Wave Visualisation':

        u_fluc = u.copy()

        v_fluc = v.copy()

        u1 = np.mean(u, axis=0)

        v1 = np.mean(v, axis=0)

        u_fluc -= u1

        v_fluc -= v1

        Ff.set(ent1t4.get())

        frame.set(ent2t4.get())

        fps = 60

        rpm = 15

        f_omega = rpm/60

        input_ang = Ff.get()

        ang = np.cos(np.deg2rad(input_ang))

        filt_freq = 2*f_omega*ang

        L = u_fluc.shape[0]

        freqs = rfftfreq(L)*fps

        ufft_vals = rfft(u_fluc, L, 0)

        trimmed = ufft_vals.copy()

        difference_array = np.abs(freqs-filt_freq)

        closest_index = difference_array.argmin()

        closest_element = freqs[closest_index]

        trimmed[(freqs<closest_element)] = 0

        trimmed[(freqs>closest_element)] = 0

        u_postFFT = irfft(trimmed, L, 0)

        f.clear()

        ax = f.add_subplot(111)

        a = np.arange(0,u_postFFT.shape[2],1)

        b = np.arange(0,u_postFFT.shape[1],1)

        A , B = np.meshgrid(a,b)

        ax.contourf(A,B,u_postFFT[frame.get(),:,:], 40, cmap='seismic')

        ax.xaxis.set_ticks([])

        ax.yaxis.set_ticks([])

        ax.plot()

        canvas.draw()

        canvas.get_tk_widget().pack()

    if choice.get() == 'Frequeny Analysis':

        print('Not yet configured')

    if choice.get() == 'Velocity Animation':

        print('Not yet configured')

    if choice.get() == 'Horizontal IW':

        u_fluc = u.copy()

        v_fluc = v.copy()

        u1 = np.mean(u, axis=0)

        v1 = np.mean(v, axis=0)

        u_fluc -= u1

        v_fluc -= v1

        Ff.set(ent1t4.get())

        frame.set(ent2t4.get())

        fps = 60

        rpm = 20

        f_omega = rpm/60

        input_ang = Ff.get()

        ang = np.cos(np.deg2rad(input_ang))

        filt_freq = 2*f_omega*ang

        L = u_fluc.shape[0]

        L1 = v_fluc.shape[0]

 

        freqs = rfftfreq(L)*fps

        freqs1 = rfftfreq(L1)*fps

 

        ufft_vals = rfft(u_fluc, L, 0)

        vfft_vals = rfft(v_fluc, L1, 0)

 

        trimmed = ufft_vals.copy()

        trimmed1 = vfft_vals.copy()

 

        difference_array = np.abs(freqs-filt_freq)

        difference_array1 = np.abs(freqs1-filt_freq)

 

        closest_index = difference_array.argmin()

        closest_element = freqs[closest_index]

        trimmed[(freqs<closest_element)] = 0

        trimmed[(freqs>closest_element)] = 0

        u_postFFT = irfft(trimmed, L, 0)

 

        closest_index1 = difference_array1.argmin()

        closest_element1 = freqs1[closest_index1]

        trimmed1[(freqs1<closest_element1)] = 0

        trimmed1[(freqs1>closest_element1)] = 0

        v_postFFT = irfft(trimmed1, L1, 0)

 

        uv_postFFT = u_postFFT+v_postFFT

 

        f.clear()

        ax = f.add_subplot(111)

        a = np.arange(0,u_postFFT.shape[2],1)

        b = np.arange(0,u_postFFT.shape[1],1)

        A , B = np.meshgrid(a,b)

        ax.contourf(A,B,uv_postFFT[frame.get(),:,:], 40, cmap='seismic')

        ax.xaxis.set_ticks([])

        ax.yaxis.set_ticks([])

        ax.plot()

        canvas.draw()

        canvas.get_tk_widget().pack()

 

choice.trace("w", callback)

 

 

######################################################### User Input frame #########################################################

 

 

input_frame = Frame(root)

input_frame.grid(row=2, column=1)

 

Label(input_frame, text="Table RPM").grid(row=0, column=0)

Label(input_frame, text="Motor RPM").grid(row=1, column=0)

Label(input_frame, text="Camera FPS").grid(row=2, column=0)

 

e1 = tk.Entry(input_frame).grid(row=0, column=1)

e2 = tk.Entry(input_frame).grid(row=1, column=1)

e3 = tk.Entry(input_frame).grid(row=2, column=1)

 

 

################################################################# Options panel 1 - Validation plots ########################################################

 

 

label1t1 = Label(tab1, text="Number of inactive rows: ")

label1t1.grid(row=1, column=0)

ent1t1 = tk.Entry(tab1)

ent1t1.grid(row=2, column=0, columnspan=2)

ent1t1.insert(0, 8)

but1t1 = Button(tab1, text='Update', command=callback, padx=15)

but1t1.grid(row=2,column=2 )

 

 

 

################################################################# Options panel 4 - Validation plots ###############################################################

 

 

label1t4 = Label(tab4, text="Filtering angle: ")

label1t4.grid(row=1, column=0)

ent1t4 = tk.Entry(tab4)

ent1t4.grid(row=2, column=0, columnspan=2)

ent1t4.insert(0, 45)

but1t4 = Button(tab4, text='Update', command=callback, padx=15)

but1t4.grid(row=2,column=2 )

 

label2t4 = Label(tab4, text="Frame: ")

label2t4.grid(row=3, column=0)

ent2t4 = tk.Entry(tab4)

ent2t4.grid(row=4, column=0, columnspan=2)

ent2t4.insert(0, 0)

but2t4 = Button(tab4, text='Update', command=callback, padx=15)

but2t4.grid(row=4,column=2 )

 
################################################################# Pressure Analysis Functions ###############################################################

def directoryClick():
    directory = filedialog.askopenfilename()
    directoryEntry.delete(0,END)
    directoryEntry.insert(0, directory)

def directoryClickProcessed():
    directory = filedialog.askopenfilename()
    directoryEntryProcessed.delete(0,END)
    directoryEntryProcessed.insert(0, directory)

def updateText(msg):
    alertBox.config(state=NORMAL)
    alertBox.delete(1.0,END)
    alertBox.insert(INSERT, msg)
    alertBox.config(state=DISABLED)


def ImportRaw():
    global u,v,x,y,dataSource
    file_ext = os.path.splitext(directoryEntry.get())
    if os.path.exists(directoryEntry.get()) == FALSE:
        updateText("That file does not exist")
        analyseButton.config(state = DISABLED)
    elif file_ext[1] != ".mat":
        updateText("Please choose a .mat data file")
        analyseButton.config(state = DISABLED)
    else:
        os.chdir(os.path.dirname(directoryEntry.get()))
        mat_contents = io.loadmat(os.path.basename(directoryEntry.get()))
        #1 for filtered, 0 for original
        #print("dataSource =",dataSource.get())
        if dataSource.get() == 1:
            u_temp = np.squeeze(mat_contents['u_filtered']) 
            v_temp = np.squeeze(mat_contents['v_filtered'])
            print("Filtered Data Imported")
        elif dataSource.get() == 0:
            u_temp = np.squeeze(mat_contents['u_original']) 
            v_temp = np.squeeze(mat_contents['v_original'])
            print("Orignal Data Imported")
        x = np.squeeze(mat_contents['x'])
        y = np.squeeze(mat_contents['y'])
        u = cleanData(u_temp)
        print("u cleaned")
        v = cleanData(v_temp)
        print("v cleaned")
        

        # u[3][2][1] refers to the entry 3rd row of the 2nd column in the 4th page
        # Remember that matlab counts e.g. from 1-100 whereas python counts 0-99
        updateText("Raw data read & cleaned successfully")
        analyseButton.config(state = NORMAL)


def ImportProcessed():
    global x_cut,y_cut,p,pagenum
    file_ext = os.path.splitext(directoryEntryProcessed.get())
    if os.path.exists(directoryEntryProcessed.get()) == FALSE:
        updateText("That file does not exist")
        analyseButton.config(state = DISABLED)
    elif file_ext[1] != ".mat":
        updateText("Please choose a .mat data file")
        analyseButton.config(state = DISABLED)
    else:
        os.chdir(os.path.dirname(directoryEntryProcessed.get()))
        mat_contents = io.loadmat(os.path.basename(directoryEntryProcessed.get()))
        x_cut = np.squeeze(mat_contents['x_cut']) 
        y_cut = np.squeeze(mat_contents['y_cut']) 
        p = np.squeeze(mat_contents['p']) 
        print("Processed data read")
        print("Plotting")
        pagenum = 0
        updatePage()
        updatePlot()
        nextButton.config(state = NORMAL)
        prevButton.config(state = NORMAL)
        updateText("Processed data read & plotted successfully")


#Current problems are occuring with how very small values are not being treated as a float (see p[2][24][50] or u[2][48][53])
#For now, will replace small values with 0
#Will be used in Import
def cleanData(a):
    a_list = [table for table in a]
    a_np = np.array(a_list)
    [a_timesteps,a_columns,a_rows] = a_np.shape
    for i in range(a_timesteps):
        for j in range(a_columns):
            for k in range(a_rows):
                if (np.isnan(a_np[i][j][k]) == TRUE):
                    #a_np[i][j][k] = "{0:.10f}".format(a_np[i][j][k])

                    a_np[i][j][k] = 0
                    #print(a_np[i][j][k])
                    #print("i = ",i)
                    #print("j =" , j)
                    #print("k =" , k)
                    #print("")

    return a_np


def rescale(u,v,x,y,width,height):
    pixelWidth = x[0][0][-1] - x[0][0][0]
    pixelHeight = y[0][-1][0] - y[0][0][0]
    xFactor = Fraction(width/pixelWidth)
    yFactor = Fraction(height/pixelHeight)
    print("xFactor:", xFactor)
    print("yFactor:", yFactor)
    #x and y have the same dimensions
    x_list = [table for table in x]
    x_np = np.array(x_list)      
    [x_timesteps,x_columns,x_rows] = x_np.shape
    x_scaled = np.zeros((x_timesteps,x_columns,x_rows))
    y_scaled = np.zeros((x_timesteps,x_columns,x_rows))
    u_scaled = np.zeros((x_timesteps,x_columns,x_rows))
    v_scaled = np.zeros((x_timesteps,x_columns,x_rows))

    x_scaled = x_scaled.astype('object')
    y_scaled = y_scaled.astype('object')
    u_scaled = u_scaled.astype('object')
    v_scaled = v_scaled.astype('object')

    for i in range(x_timesteps):
        for j in range(x_columns):
            for k in range(x_rows):
                x_scaled[i][j][k] = Fraction(xFactor * x[i][j][k])
                u_scaled[i][j][k] = Fraction(xFactor * u[i][j][k])
                y_scaled[i][j][k] = Fraction(yFactor * y[i][j][k])
                v_scaled[i][j][k] = Fraction(yFactor * v[i][j][k])
    print("Rescaled pixels to meters")


    return [u_scaled,v_scaled,x_scaled,y_scaled]
                





def updatePlot():
    global pagenum, x_cut, y_cut, p, mycmap, plotFormat
    f.clf()
    #print("plotFormat =" , plotFormat)
    ax = f.add_subplot(1,1,1)
    if plotFormat.get() == 0:
        #Filled contour plot
        cf = ax.contourf(x_cut[pagenum,:,:],y_cut[pagenum,:,:],p[pagenum,:,:],20, cmap = mycmap)


    elif plotFormat.get() == 1:
        #Normal contour plot 
        cf = ax.contour(x_cut[pagenum,:,:],y_cut[pagenum,:,:],p[pagenum,:,:],20, cmap = mycmap)

    elif plotFormat.get() == 2:
        #Mesh
        cf = ax.pcolormesh(x_cut[pagenum,:,:],y_cut[pagenum,:,:],p[pagenum,:,:])


    #Filled Contour Plot
    #cf = ax.contourf(x_cut[pagenum,:,:],y_cut[pagenum,:,:],p[pagenum,:,:],20, cmap = mycmap)

    #Normal Contour Plot
    #cf = ax.contour(x_cut[pagenum,:,:],y_cut[pagenum,:,:],p[pagenum,:,:],20, cmap = mycmap)

    #Mesh
    #cf = ax.pcolormesh(x_cut[pagenum,:,:],y_cut[pagenum,:,:],p[pagenum,:,:])


    f.colorbar(cf,ax = ax)
    cf.set_clim(vmin = np.amin(p), vmax = np.amax(p))
    canvas.draw()

def scaleFunc(a):
    global scaleFactor
    a_list = [table for table in a]
    a_np = np.array(a_list)
    [a_timesteps,a_columns,a_rows] = np.shape(a_np)
    a_temp = np.zeros((a_timesteps,a_columns,a_rows))
    for i in range(a_timesteps):
        for j in range(a_columns):
            for k in range(a_rows):
                a_temp[i][j][k] = a[i][j][k] * scaleFactor
    return a_temp

def triggerAnalysis():
    global x_cut, y_cut, p, pagenum, u, v, x, y
    updateText("Analysing...")   
    #[u_scaled,v_scaled,x_scaled,y_scaled] = [u,v,x,y]
    [u_scaled,v_scaled,x_scaled,y_scaled] = rescale(u,v,x,y,float(widthEntry.get()),float(heightEntry.get()))
    
    t0 = time.perf_counter()
    [x_cut,y_cut,p] = pressureAnalysis(u_scaled,v_scaled,x_scaled,y_scaled,float(stepsizeEntry.get()),float(viscosityEntry.get()),float(densityEntry.get()))
    t1 = time.perf_counter()
    t = t1 - t0
    print("Time taken: ", t)
    #figsize is figure size in inches, dpi is dots per sq inch
    print("Plotting...")
    #f.clear()
    pagenum = 0
    updatePage()
    updatePlot()
    #f.colorbar(presplot)
    #presplot.colorbar()
    nextButton.config(state = NORMAL)
    prevButton.config(state = NORMAL)
    passtoFile()
    updateText("Success - Values saved in file")

#Note that there could be a way to reduce memory usage by combining updateText and updatePage into one function
def updatePage():
    pageLabel.config(state = NORMAL)
    pageLabel.delete(1.0,END)
    pageLabel.insert(INSERT, pagenum)
    pageLabel.config(state=DISABLED)

#Current replotting will just overwrite the old one, resulting in some glitches
def next():
    global pagenum 
    #f.clear()
    stepcount = x_cut.shape[0]
    if (pagenum == stepcount-1):
        updateText("No more pages")
    else:
        #canvas.delete("all")
        pagenum += 1
        updatePage()
        updatePlot()


def prev():
    global pagenum
    #f.clear()
    if (pagenum == 0):
        updateText("No previous page")
    else: 
        pagenum -= 1
        updatePage()
        updatePlot()


def passtoFile():
    global x_cut, y_cut, p, fileName, u, v, x, y
    os.chdir(os.path.dirname(directoryEntry.get()))
    
    var = {}
    var['x_cut'] = x_cut
    var['y_cut'] = y_cut
    var['p'] = p
    var['u'] = u
    var['v'] = v
    var['x'] = x
    var['y'] = y
    file_ext = os.path.splitext(directoryEntry.get())
    saveName = file_ext[0] + "_" + fileName
    io.savemat(saveName, var)




################################################################# Options panel 5 - Pressure from raw ###############################################################

directoryButton = Button(tab6, text = 'Select File', command = directoryClick)
directoryButton.grid(row = 1,column = 0)

directoryEntry = Entry(tab6)
directoryEntry.grid(row = 1,column = 1)
directoryEntry.delete(0,END)
directoryEntry.insert(0, r"E:/John/Documents/University/URSS/RankineVortex_R1.mat")

#Import only works for .mat files, PIVlab outputs .m files. To get around this, just open the file and resave the variables separately
directoryImportRaw = Button(tab6, text = 'Import', command = ImportRaw)
directoryImportRaw.grid(row = 1, column = 2)


#1 for filtered, 0 for original
dataSource = IntVar()
Radiobutton(tab6, text = "Original", variable = dataSource, value = 0).grid(row = 2, column = 0)
Radiobutton(tab6, text = "Filtered", variable = dataSource, value = 1).grid(row = 2, column = 1)


analyseButton = Button(tab6, text = 'Analyse!', command = triggerAnalysis, state = DISABLED)
analyseButton.grid(row = 3, column = 1)

Label(tab6, text = "Time step size (s):").grid(row = 4, column = 0)
stepsizeEntry = Entry(tab6)
stepsizeEntry.insert(0, "1")
stepsizeEntry.grid(row = 4, column = 1)

Label(tab6, text = "Kinematic Viscosity (m^2/s):").grid(row = 5, column = 0)
viscosityEntry = Entry(tab6)
#Default value is that of water
viscosityEntry.insert(0, "0.294")
viscosityEntry.grid(row = 5, column = 1)

Label(tab6, text = "Density (kg/m^3):").grid(row = 6, column = 0)
densityEntry = Entry(tab6)
#Default value is that of water
densityEntry.insert(0, "997")
densityEntry.grid(row = 6, column = 1)

Label(tab6, text = "Width of images (m):").grid(row = 7, column = 0)
widthEntry = Entry(tab6)
#Default is 1
widthEntry.insert(0, "1")
widthEntry.grid(row = 7, column = 1)

Label(tab6, text = "Height of images (m):").grid(row = 8, column = 0)
heightEntry = Entry(tab6)
#Default is 1
heightEntry.insert(0, "1")
heightEntry.grid(row = 8, column = 1)


plotFormat = IntVar()
Radiobutton(tab6, text = "Filled Contour Plot",variable = plotFormat, value = 0).grid(row = 9, column = 0)
Radiobutton(tab6, text = "Normal Contour Plot",variable = plotFormat, value = 1).grid(row = 9, column = 1)
Radiobutton(tab6, text = "Mesh",variable = plotFormat, value = 2).grid(row = 9, column = 2)

################################################################# Options panel 6 - Pressure from processed ###############################################################

directoryButtonProcessed = Button(tab7, text = 'Select File', command = directoryClickProcessed)
directoryButtonProcessed.grid(row = 0,column = 0)

directoryEntryProcessed = Entry(tab7)
directoryEntryProcessed.grid(row = 0,column = 1)
directoryEntryProcessed.delete(0,END)
directoryEntryProcessed.insert(0, r"E:\John\Documents\University\URSS\PressureData.mat")
    
directoryImportProcessed = Button(tab7, text = 'Import', command = ImportProcessed)
directoryImportProcessed.grid(row = 0, column = 2)

Radiobutton(tab7, text = "Filled Contour Plot",variable = plotFormat, value = 0).grid(row = 9, column = 0)
Radiobutton(tab7, text = "Normal Contour Plot",variable = plotFormat, value = 1).grid(row = 9, column = 1)
Radiobutton(tab7, text = "Mesh",variable = plotFormat, value = 2).grid(row = 9, column = 2)

################################################################# Other added components ###############################################################
Label(root, text = "Alerts:").grid(row = 18, column = 0)
alertBox = Text(root,state = DISABLED, height = 1, width = 40)
alertBox.grid(row = 18, column = 1)
 
prevButton = Button(root, text = 'Previous Image', command = prev, state = DISABLED)
prevButton.grid(row = 20,column = 0)

nextButton = Button(root, text = 'Next Image', command = next,state = DISABLED)
nextButton.grid(row = 20,column = 2)


Label(root, text = "Page Number:").grid(row = 19, column = 1)
pageLabel = Text(root, state = NORMAL, height = 1, width = 4)
pageLabel.delete(1.0,END)
pageLabel.insert(INSERT, pagenum)
pageLabel.config(state = DISABLED)
pageLabel.grid(row = 20, column = 1)
 #############################################################

root.mainloop()