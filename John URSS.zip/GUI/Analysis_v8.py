import numpy as np
from matplotlib import pyplot as plt 

#Change from v3 - Altered returned value of p to keep average pressure constant 
#Change from v5 - Propagate from all 4 corners and average instead of just the one corner
#Change from v6 - Corrected formula for pressure, and removed 2 corners from the propagation algorithm to reduce run time
#Change from v7 - Changed method of calculating from differebnt corners to occur in pressureAnalysis
#for bug fixing
import time


#Current problems are occuring with how very small values are not being treated as a float (see p[2][24][50] or u[2][48][53])
#For now, will replace small values with 0


def pressureAnalysis(u,v,x,y,stepsize,viscosity,density):
    #Returns x_cut,y_cut,p


    dudx = xDer(u,x)
    #print("x =", x)
    #print("u =", u)
    #print("dx =", dx)
    print("dudx complete")
    dvdx = xDer(v,x)
    print("dvdx complete")
    dudy = yDer(u,y)
    print("dudy complete")
    dvdy = yDer(v,y)
    print("dvdy complete")
    #print("y =", y)
    #print("v =", v)
    #print("dy =", dy)

    d2udx2 = xdoubDer(dudx,x)
    print("d2udx2 complete")
    d2vdx2 = xdoubDer(dvdx,x)
    print("d2vdx2 complete")
    d2udy2 = ydoubDer(dudy,y)
    print("d2udy2 complete")
    d2vdy2 = ydoubDer(dvdy,y)
    print("d2vdy2 complete")

    #print("d2x =", d2x)
    #print("d2y =", d2y)


    
    #print("stepsize =", stepsize)
    dudt = tDer(u,stepsize)
    print("dudt complete")
    dvdt = tDer(v,stepsize)
    print("dvdt complete")
    #print("dut =", dut)
    #print("dvt =", dvt)

    #print ("viscosity =", viscosity)
    
    #print("density =", density)
    [pDerX,pDerY] = pressureDirDer(u,v,dudx,dvdx,d2udx2,d2vdx2,dudy,dvdy,d2udy2,d2vdy2,dudt,dvdt,viscosity,density)
    print("pressureDirDer complete")
    
    #print("pDerX =", pDerX)
    #print("pDerY =", pDerY)

    p_TL = presfromDer(x,y,pDerX,pDerY,stepsize)
    print("presfromDer for TL complete")
    p_TR = np.fliplr(presfromDer(np.fliplr(x),np.fliplr(y),np.fliplr(pDerX),np.fliplr(pDerY),stepsize))
    print("presfromDer for TR complete")
    p_BL = np.flipud(presfromDer(np.flipud(x),np.flipud(y),np.flipud(pDerX),np.flipud(pDerY),stepsize))
    print("presfromDer for BL complete")
    p_BR =  np.flipud(np.fliplr(presfromDer( np.flipud(np.fliplr(x)), np.flipud(np.fliplr(y)), np.flipud(np.fliplr(pDerX)), np.flipud(np.fliplr(pDerY)),stepsize)))
    print("presfromDer for BR complete")


    p_TL_list = [table for table in p_TL]
    p_TL_np = np.array(p_TL_list)
    [p_timesteps,p_columns,p_rows] = np.shape(p_TL_np)
    p = np.zeros((p_timesteps,p_columns,p_rows))
    for i in range(p_timesteps):
        for j in range(p_columns):
            for k in range(p_rows):
                p[i][j][k] = (p_TL[i][j][k] + p_TR[i][j][k] + p_BL[i][j][k] + p_BR[i][j][k]) / 4
    print("p calculated")
    
    #print("p = ", p)    

    #p is 4 rows shorter than x & y, and is missing the first and last time step 
    #x and y should be the same size, so will cheat here and use the same code to cut y down to size
    x_list = [table for table in x]
    x_np = np.array(x_list)
    [x_timesteps, x_columns, x_rows] = x_np.shape
    x_cut = np.zeros((x_timesteps-2,x_columns-4,x_rows-4))
    y_cut = np.zeros((x_timesteps-2,x_columns-4,x_rows-4))
    for i in range(x_timesteps-2):
        for j in range(x_columns-4):
            for k in range(x_rows-4):
                x_cut[i][j][k] = x[i+1][j+2][k+2]
                y_cut[i][j][k] = y[i+1][j+2][k+2]

    print("x_cut and y_cut constructed")

    return [x_cut,y_cut,p]

def xDer(u,x):  
    # This loop can be used to get derivatives in the x direction. We would need to transpose "timestep" to get a loop for derivatives in the y direction
    # u[3][2][1] refers to the entry 3rd row of the 2nd column in the 4th page
    #du/dx ~= (u(x+h/2,y,t)-u(x-h/2,y,t))/h
    #i counts page
    #j counts columns
    #k counts values in row

    #Will assumed sizes of images does not change throughout
    #Need to generate the correct dimensions of the array
    du_dx = [[[0]]]
    u_list = [table for table in u]
    u_np = np.array(u_list)
    
    #print("u_np[0][0][0] =", u_np[0][0][0]) # 1,1 element in first table
    #print("u_np[1][0][0] =", u_np[1][0][0]) # 1,1 element in second table
    #print("u_np[0][1][0] =", u_np[0][1][0]) # 2,1 in first
    #print("u_np[0][0][1] =", u_np[0][0][1]) # 1,2 in first 
    #print("u.ndim =", u.ndim)
    #print("u_np.ndim =", u_np.ndim)

    [u_timesteps,u_columns,u_rows] = u_np.shape
    #print(u_np.shape)
    #Remove columns to keep du_dx and du_dy the same size
    du_dx = np.zeros((u_timesteps,(u_columns-2),(u_rows-2)))

    i = 0
    for timestep in u:
        page = np.array(timestep)
        [pagerows,pagecolumns] = page.shape
        #print("i =",i)
        for j in range(pagerows):
            #print("j =" , j)
            for k in range(pagecolumns):
                #print("k =" , k)
                #We have the data to calculate this derivative, this is just so that xDer and yDer output arrays with the same dimension
                if (j == 0) or (j == (pagerows-1)):
                    pass
                elif (k == 0) or (k == (pagecolumns-1)):
                    pass
                else:
                    h = x[i][j][k+1] - x[i][j][k-1]
                    #Extra - is needed below since otherwise we get a "border" of empty cells in the array
                    du_dx[i][j-1][k-1] = (u[i][j][k+1] - u[i][j][k-1])/h

                        
                    #print(du_dx[i][j][k-1])
        i = i+1
    return du_dx     

def yDer(v,y):  
    # This loop can be used to get derivatives in the x direction. We would need to transpose "timestep" to get a loop for derivatives in the y direction
    # u[3][2][1] refers to the entry 3rd row of the 2nd column in the 4th page
    #du/dx ~= (u(x+h/2,y,t)-u(x-h/2,y,t))/h
    #i counts page
    #j counts columns
    #k counts values in row

    #Will assumed sizes of images does not change throughout
    #Need to generate the correct dimensions of the array
    du_dy = [[[0]]]
    v_list = [table for table in v]
    v_np = np.array(v_list)      
    [v_timesteps,v_columns,v_rows] = v_np.shape
    du_dy = np.zeros((v_timesteps,(v_columns-2),(v_rows-2)))

    i = 0
    for timestep in v:
        page = np.array(timestep)
        [pagerows,pagecolumns] = page.shape
        #print("i =",i)
        for j in range(pagerows):
            #print("j =" , j)
            for k in range(pagecolumns):
                #print("k =" , k)
                if (j == 0) or (j == (pagerows-1)):
                    pass
                elif (k == 0) or (k == (pagecolumns-1)):
                    pass
                else:
                    
                    h = y[i][j+1][k] - y[i][j-1][k]
                    #Extra - is needed below since otherwise we get a "border" of empty cells in the array
                    du_dy[i][j-1][k-1] = (v[i][j+1][k] - v[i][j-1][k])/h
                    #print(du_dy[i][j-1][k-1])
        i = i+1
    return du_dy    

def xdoubDer(du_dx,x):  
    # This loop can be used to get derivatives in the x direction. We would need to transpose "timestep" to get a loop for derivatives in the y direction
    # u[3][2][1] refers to the entry 3rd row of the 2nd column in the 4th page
    #du/dx ~= (u(x+h/2,y,t)-u(x-h/2,y,t))/h
    #i counts page
    #j counts columns
    #k counts values in row

    #Will assumed sizes of images does not change throughout
    #Need to generate the correct dimensions of the array
    d2u_dx2 = [[[0]]]
    du_dx_np = np.array(du_dx)      
    [du_dx_timesteps,du_dx_columns,du_dx_rows] = du_dx_np.shape
    d2u_dx2 = np.zeros((du_dx_timesteps,(du_dx_columns-2),(du_dx_rows-2)))

    i = 0
    for timestep in du_dx:
        page = np.array(timestep)
        [pagerows,pagecolumns] = page.shape
        #print("i =",i)
        for j in range(pagerows):
            #print("j =" , j)
            for k in range(pagecolumns):
                #print("k =" , k)
                if (j == 0) or (j == (pagerows-1)):
                    pass
                elif (k == 0) or (k == (pagecolumns-1)):
                    pass
                else:
                    #Position will be offset due to du_dx not containing border values 
                    h = x[i][j+1][k+2] - x[i][j+1][k]
                    #Extra - is needed below since otherwise we get a "border" of empty cells in the array
                    d2u_dx2[i][j-1][k-1] = (du_dx[i][j][k+1] - du_dx[i][j][k-1])/h
                    #print(d2u_dx2[i][j][k-1])
        i = i+1
    return d2u_dx2  

def ydoubDer(du_dy,y):  
    # This loop can be used to get derivatives in the x direction. We would need to transpose "timestep" to get a loop for derivatives in the y direction
    # u[3][2][1] refers to the entry 3rd row of the 2nd column in the 4th page
    #du/dx ~= (u(x+h/2,y,t)-u(x-h/2,y,t))/h
    #i counts page
    #j counts columns
    #k counts values in row

    #Will assumed sizes of images does not change throughout
    #Need to generate the correct dimensions of the array
    d2u_dy2 = [[[0]]]
    du_dy_np = np.array(du_dy)      
    [du_dy_timesteps,du_dy_columns,du_dy_rows] = du_dy_np.shape
    d2u_dy2 = np.zeros((du_dy_timesteps,(du_dy_columns-2),(du_dy_rows-2)))

    i = 0
    for timestep in du_dy:
        page = np.array(timestep)
        [pagerows,pagecolumns] = page.shape
        #print("i =",i)
        for j in range(pagerows):
            #print("j =" , j)
            for k in range(pagecolumns):
                #print("k =" , k)
                if (j == 0) or (j == (pagerows-1)):
                    pass
                elif (k == 0) or (k == (pagecolumns-1)):
                    pass
                else:
                    #Position will be offset due to du_dx not containing border values 
                    h = y[i][j+2][k+1] - y[i][j][k+1]
                    #Extra - is needed below since otherwise we get a "border" of empty cells in the array
                    d2u_dy2[i][j-1][k-1] = (du_dy[i][j+1][k] - du_dy[i][j-1][k])/h
                    #print(d2u_dx2[i][j][k-1])
        i = i+1
    return d2u_dy2  

def tDer(u,stepsize):
    #Will assume dimensions don't change throughout
    # Can use this for both du_dt and dv_dt, notation here is for the former case
    du_dt = [[[0]]]
    u_list = [table for table in u]
    u_np = np.array(u_list)      
    [u_timesteps,u_columns,u_rows] = u_np.shape
    #print(u_np.shape)
    du_dt = np.zeros(((u_timesteps-2),u_columns,u_rows))
    for j in range(u_columns):
        #print("j =" , j)
        for k in range(u_rows):
            #print("k =" , k)
            for i in range(u_timesteps):
                #print("i =", i)
                #print("j =", j)
                #print("k =", k)
                if (i == 0) or (i == (u_timesteps-1)):
                    pass
                else:
                    #print((u[i+1][j][k] - u[i-1][j][k-1]))
                    #print(stepsize)
                    du_dt[i-1][j][k] = (u[i+1][j][k] - u[i-1][j][k-1])/float(stepsize)
                    #print(du_dx[i][j][k-1])
        
    return du_dt     

## def tDerY(v,stepsize):
##    #Will assume dimensions don't change throughout
##    dv_dt = [[[0]]]
##    v_np = np.array(v)      
##    [v_timesteps,v_columns,v_rows] = v_np.shape
##    #print(v_np.shape)
##    dv_dt = np.zeros(((v_timesteps-2),v_columns,v_rows))
##    for j in range(v_rows):
##        #print("j =" , j)
##        for k in range(v_columns):
##            #print("k =" , k)
##            for i in range(v_timesteps):
##                if (i == 0) or (i == (v_timesteps-1)):
##                    pass
##                else:
##                    dv_dt[i-1][j][k] = (v[i+1][j][k] - v[i-1][j][k-1])/stepsize
##                    #print(du_dx[i][j][k-1])
##    return dv_dt

#Completely reworked from v6
def pressureDirDer(u,v,dudx,dvdx,d2udx2,d2vdx2,dudy,dvdy,d2udy2,d2vdy2,dudt,dvdt,viscosity,density):
    # Swap u->v, du_dx -> dv_dy, d2u_dx2 -> d2v_dy2, du_dt -> dv/dt to get other directional derivative
    # If u is size (a,b,c)
    # du_dx is size (a,b-2,c-2)
    # d2u_dx2 is size (a,b-4,c-4)
    # du_dt is size (a-2,b,c)
    # viscosity and density are constants
    dp_dx = [[[0]]]
    dp_dy = [[[0]]]
    u_list = [table for table in u]
    u_np = np.array(u_list)      
    [u_timesteps,u_columns,u_rows] = u_np.shape # [a,b,c]
    dp_dx = np.zeros((u_timesteps-2,u_columns-4,u_rows-4))
    dp_dy = np.zeros((u_timesteps-2,u_columns-4,u_rows-4))
    for i in range(u_timesteps-2):
        for j in range(u_columns-4):
            for k in range(u_rows-4):
                #Viscous
                dp_dx[i][j][k] = (-1)*density*(dudt[i][j+2][k+2] + (u[i+1][j+2][k+2] * dudx[i+1][j+1][k+1]) + (v[i+1][j+2][k+2] * dudy[i+1][j+1][k+1]) - (viscosity * (d2udx2[i+1][j][k] + d2udy2[i+1][j][k])))
                dp_dy[i][j][k] = (-1)*density*(dvdt[i][j+2][k+2] + (u[i+1][j+2][k+2] * dvdx[i+1][j+1][k+1]) + (v[i+1][j+2][k+2] * dvdy[i+1][j+1][k+1]) - (viscosity * (d2vdx2[i+1][j][k] + d2vdy2[i+1][j][k])))
                #Inviscous
                #dp_dx[i][j][k] = (-1)*density*(dudt[i][j+2][k+2] + (u[i+1][j+2][k+2] * dudx[i+1][j+1][k+1]) + (v[i+1][j+2][k+2] * dudy[i+1][j+1][k+1]))
                #dp_dy[i][j][k] = (-1)*density*(dvdt[i][j+2][k+2] + (u[i+1][j+2][k+2] * dvdx[i+1][j+1][k+1]) + (v[i+1][j+2][k+2] * dvdy[i+1][j+1][k+1]))
    return [dp_dx,dp_dy]



def presfromDer(x,y,pDerX,pDerY,stepsize):
    # x and y have 4 extra rows and columns compared to pDerX and pDerY, and 2 more tables 
    #pDerX & pDerY and x & y have the same dimensions
    pDerX_np = np.array(pDerX)
    [p_timesteps,p_columns,p_rows] = pDerX_np.shape
    p_topleft = np.zeros([p_timesteps,p_columns,p_rows])
    #p_topright = np.zeros([p_timesteps,p_columns,p_rows])
    #p_bottomleft = np.zeros([p_timesteps,p_columns,p_rows])
    #p_bottomright = np.zeros([p_timesteps,p_columns,p_rows])
    p = np.zeros([p_timesteps,p_columns,p_rows])
    #Assume top left space has pressure equal to 0 (can adjust based on real values)
    #Will use dp_dt to find top left pressure in each timestep
    #Then move row by row finding pressure based on value immediately to the left. To generate the leftmost column, we will iterate using pDerY
    #Our estimates of the pressure are therefore dependent on pDerX, pDerY, and dp_dt in descending order


    #Count number of cells
    size = 0
    #Add all values
    total = 0.0

    for i in range(p_timesteps):
        for j in range(p_columns):
            for k in range(p_rows):
                if (j==0) and (k==0):
                    pass
                elif (k==0) and (j!=0):
                    #y increases going down the array
                    p_topleft[i][j][0] = p_topleft[i][j-1][0] + (pDerY[i][j][0] * (y[i+1][j+2][2]-y[i+1][j+1][2]))
                    #p_topright[i][j][p_rows-1] = p_topright[i][j-1][p_rows-1] + (pDerY[i][j][p_rows-1] * (y[i+1][j+2][p_rows-3]-y[i+1][j+1][p_rows-3]))
                    #p_bottomleft[i][-j-1][0] = p_bottomleft[i][-j][0] + (pDerY[i][-j-1][0] * (y[i+1][-j][2]-y[i+1][-j-1][2]))
                    #p_bottomright[i][-j-1][p_rows-1] = p_bottomright[i][-j][0] + (pDerY[i][-j-1][p_rows-1] * (y[i+1][-j][p_rows-3]-y[i+1][-j-1][p_rows-3]))
                elif (j==0) and (k!=0):
                    #x increases along the array
                    p_topleft[i][0][k] = p_topleft[i][0][k-1] + (pDerX[i][0][k] * (x[i+1][2][k+2] - x[i+1][2][k+1]))
                    #p_topright[i][0][-k-1] = p_topright[i][0][-k] + (pDerX[i][0][-k-1] * (x[i+1][2][-k] - x[i+1][2][-k-1]))
                    #p_bottomleft[i][p_columns-1][k] = p_bottomleft[i][p_columns-1][k-1] + (pDerX[i][p_columns-1][k] * (x[i+1][p_columns-3][k+2] - x[i+1][p_columns-3][k+1]))
                    #p_bottomright[i][p_columns-1][-k-1] = p_bottomright[i][p_columns-1][-k] + (pDerX[i][p_columns-1][-k-1] * (x[i+1][p_columns-3][-k] - x[i+1][p_columns-3][-k-1]))

                elif (j!=0) and (k!=0):
                    p_topleft[i][j][k] = ((p_topleft[i][j][k-1] + (pDerX[i][j][k] * (x[i+1][j+2][k+2] - x[i+1][j+2][k+1]))) + (p_topleft[i][j-1][k] + (pDerY[i][j][k] * (y[i+1][j+2][k+2]-y[i+1][j+1][k+2]))))/2
                    #p_topright[i][j][-k-1] = (((p_topright[i][j][-k] + (pDerX[i][j][-k-1] * (x[i+1][j+2][-k] - x[i+1][j+2][-k-1])))) + (p_topright[i][j-1][-k-1] + (pDerY[i][j][-k-1] * (y[i+1][j+2][-k-3]-y[i+1][j+1][-k-3]))))/2
                    #p_bottomleft[i][-j-1][k] = ((p_bottomleft[i][-j-1][k-1] + (pDerX[i][-j-1][k] * (x[i+1][j-3][k+2] - x[i+1][j-3][k+1])))+(p_bottomleft[i][-j][k] + (pDerY[i][-j-1][k] * (y[i+1][-j][2]-y[i+1][-j-1][k+2]))))/2
                    #p_bottomright[i][-j-1][-k-1] = ((p_bottomright[i][-j-1][-k] + (pDerX[i][-j-1][-k-1] * (x[i+1][-j-3][-k] - x[i+1][-j-3][-k-1])))+(p_bottomright[i][-j][-k-1] + (pDerY[i][-j-1][-k-1] * (y[i+1][-j][-k-3]-y[i+1][-j-1][-k-3]))))/2

                
                #p[i][j][k] = (p_topleft[i][j][k] + p_topright[i][j][k] + p_bottomleft[i][j][k] + p_bottomright[i][j][k])/4
                #p[i][j][k] = (p_topleft[i][j][k] + p_bottomright[i][j][k])/2
                p[i][j][k] = p_topleft[i][j][k]
                
                total += float(p[i][j][k])
                #if (np.isnan(total)):
                    #print("i = ", i)
                    #print("j =", j)
                    #print("k =", k)
                    #time.sleep(100)
                size = size + 1


    #Bug testing using default analyse function
    #print(pDerX[2][24][50])
    #print(pDerY[2][24][50])
    #print(p[2][24][50])
    #total += p[1][1][1]
    #print("isnan total =", np.isnan(total))
    average = total / size
    #print(total)
    #print(size)
    #print(average)
    for i in range(p_timesteps):
        for j in range(p_columns):
            for k in range(p_rows):
                p[i][j][k] -= float(average)
                pass
    return p
    


## x = np.random.rand(3,5,5)
## u = np.random.rand(3,5,5)
## dx = xDer(u,x)
## print("x =", x)
## print("u =", u)
## print("dx =", dx)
## y = np.random.rand(3,5,5)
## v = np.random.rand(3,5,5)
## dy = yDer(v,y)
## print("y =", y)
## print("v =", v)
## print("dy =", dy)

## d2x = xdoubDer(dx,x)
## d2y = ydoubDer(dy,y)
## print("d2x =", d2x)
## print("d2y =", d2y)


## step = 1
## print("step =", step)
## dut = tDer(u,step)
## dvt = tDer(v,step)
## print("dut =", dut)
## print("dvt =", dvt)
## vis = 1
## print ("vis =", vis)
## den = 1
## print("den =", den)
## pDerX = pressureDirDer(u,dx,d2x,dut,vis,den)
## pDerY = pressureDirDer(v,dy,d2y,dvt,vis,den)
## print("pDerX =", pDerX)
## print("pDerY =", pDerY)